"""
《统计学习方法》第4章 朴素贝叶斯
"""

from test import test

test()