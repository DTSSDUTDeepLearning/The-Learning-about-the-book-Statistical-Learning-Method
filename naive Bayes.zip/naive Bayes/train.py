"""
训练朴素贝叶斯算法的分类器模型
贝叶斯估计的我就不写了，只需要加lamada就行

其中，
p_y[i,0]表示p(Y = Ym[i])
p_x1_y[i,j]表示p(X = X1[j] | Y = Ym[i])
p_x2_y[i,j]表示p(X = X1[j] | Y = Ym[i])
因此，输出的顺序与书本第50页、51页的例4.1的输出顺序有所不同
"""


import numpy as np

def model():
    #样本的特征的取值范围
    A1 = np.array([1, 2, 3])
    A2 = np.array(['S', 'M', 'L'])
    #在这里，我本来想用一个二维的数组将A全部写进来。但是考虑到每个特征X(j)的取值范围的个数可能不同，不方便使用numpy库，所以分开写成A1,A2
    Ym = np.array([1, -1])

    #模型用若干个矩阵保存起来
    p_y = np.zeros((Ym.size,1))
    p_x1_y = np.zeros((Ym.size,A1.size))
    p_x2_y = np.zeros((Ym.size,A2.size))

    #样本
    X1 = (1,1,1,1,1,2,2,2,2,2,3,3,3,3,3)
    X2 = ('S','M','M','S','S','S','M','M','L','L','L','M','M','L','L')
    Y = (-1,-1,1,1,-1,-1,-1,1,1,1,1,1,1,1,-1)
    len = 15

    #求出现次数
    for i in range(Ym.size):
        for j in range(len):
            if Y[j] == Ym[i]:
                p_y[i,0]+=1
                for k1 in range(A1.size):
                    if X1[j] == A1[k1]:
                        p_x1_y[i,k1]+=1
                for k2 in range(A2.size):
                    if X2[j] == A2[k2]:
                        p_x2_y[i,k2]+=1

    #除法运算，求概率
    for i in range(Ym.size):
        p_x1_y[i,:] /= p_y[i,0]
        p_x2_y[i,:] /= p_y[i,0]
    for i in range(Ym.size):
        p_y[i,0] /= len

    """
    print(p_y)
    print(p_x1_y)
    print(p_x2_y)
    """

    return p_y, p_x1_y, p_x2_y, A1, A2, Ym