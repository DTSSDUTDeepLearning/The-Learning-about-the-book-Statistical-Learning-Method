"""
对实例x=(2,S).T进行测试
"""

import numpy as np
from train import model

def test():
    p_y, p_x1_y, p_x2_y, A1, A2, Ym = model()
    x = np.array([2,'S'])
    y_1 = p_y[0]
    y_2 = p_y[1] #表示y = -1时的极大似然估计

    #分别计算两个极大似然估计
    for i in range(A1.size):
        if A1[i] == x[0]:
            y_1 *= p_x1_y[0,i]
            y_2 *= p_x1_y[1,i]
    for i in range(A2.size):
        if A2[i] == x[1]:
            y_1 *= p_x2_y[0,i]
            y_2 *= p_x2_y[1,i]

    if y_1 > y_2:
        print("分类应当为1")
    else:
        print("分类应当为-1")